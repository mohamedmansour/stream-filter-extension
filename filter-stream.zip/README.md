Filter Stream for Google+ Chrome Extension
=====================================

In light of recent events, I've felt the need to include certain filtering
mechanisms to exlude posts from your stream. With this extension, it will allow
you to add filter keywords which will remove posts that include that keyword.

Follow me on [Google+](https://plus.google.com/116805285176805120365/about)

Icons
-----------------
Icon designed by [Andy Shaw](https://plus.google.com/104156719397280448257/about)

Screenshots
-----------------
![Screenshot of the Chrome Extension](https://github.com/mohamedmansour/google-plus-extension/raw/master/screenshot/marquee.png)


